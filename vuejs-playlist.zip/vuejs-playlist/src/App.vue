<template>
  <div>
    <app-header></app-header>
  <router-view></router-view>
   
  </div>
</template>

<script>
//Importing the component files I created the functions, HTML & CSS in
import addBlog from './components/addBlog.vue';
import showBlogs from './components/showBlogs.vue';
import listBlogs from './components/listBlogs.vue';
import header from './components/header.vue';

export default {
  //Making use of my imports so that I can read them out to the DOM
  components: {
    'add-blog': addBlog,
    'show-blogs': showBlogs,
    'list-blogs': listBlogs,
    'app-header': header
  },
  data() {
    return {

    };
  },
  methods: {}
};

</script>

<style scoped>
body{
    margin: 0;
    font-family: 'Roboto', sans-serif;
}
</style>
