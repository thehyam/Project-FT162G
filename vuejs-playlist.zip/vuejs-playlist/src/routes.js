//Importing the necessary data I need to create my routes
import showBlogs from './components/showBlogs';
import addBlog from './components/addBlog';
import singleBlog from './components/singleBlog';

//Creating my routes
export default [
    {path: '/', component: showBlogs},
    {path: '/add', component: addBlog},
    {path: '/blog/:id', component: singleBlog }
]

